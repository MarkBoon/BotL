package net.minecraft.src;

class ComponentScatteredFeaturePieces2
{
}
